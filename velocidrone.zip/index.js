// index.js (stub)
import './index.mjs';
